CREATE DATABASE agenda_telefonica;
USE agenda_telefonica;

CREATE TABLE contato (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  telefone VARCHAR(20) NOT NULL,
  email VARCHAR(100)
);
