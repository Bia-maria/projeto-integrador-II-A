import java.sql.*;
import java.util.Scanner;

public class AgendaMenu {
    static String url = "jdbc:mysql://localhost:3306/agenda_telefonica";
    static String user = "root";
    static String password = "";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Sistema de Agenda Telefônica");
    }
}
