package agendatelefonica;

import java.util.Scanner;

public class AgendaTeste {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ContatoDAO dao = new ContatoDAO();

        int opcao;

        do {

            System.out.println("\n===== AGENDA TELEFÔNICA =====");
            System.out.println("1 - Adicionar contato");
            System.out.println("2 - Buscar contato");
            System.out.println("3 - Listar contatos");
            System.out.println("4 - Atualizar contato");
            System.out.println("5 - Remover contato");
            System.out.println("6 - Sair");
            System.out.print("Escolha: ");

            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {

                case 1:

                    System.out.print("Nome: ");
                    String nome = sc.nextLine();

                    System.out.print("Telefone: ");
                    String telefone = sc.nextLine();

                    System.out.print("Email: ");
                    String email = sc.nextLine();

                    Contato contato =
                            new Contato(nome, telefone, email);

                    dao.adicionarContato(contato);

                    break;

                case 2:

                    System.out.print("Nome para buscar: ");
                    dao.buscarContato(sc.nextLine());

                    break;

                case 3:

                    dao.listarContatos();

                    break;

                case 4:

                    System.out.print("Nome do contato: ");
                    nome = sc.nextLine();

                    System.out.print("Novo telefone: ");
                    telefone = sc.nextLine();

                    System.out.print("Novo email: ");
                    email = sc.nextLine();

                    dao.atualizarContato(
                            nome,
                            telefone,
                            email
                    );

                    break;

                case 5:

                    System.out.print("Nome do contato: ");
                    dao.removerContato(sc.nextLine());

                    break;

                case 6:

                    System.out.println("Encerrando sistema...");

                    break;

                default:

                    System.out.println("Opção inválida!");

            }

        } while (opcao != 6);

        sc.close();
    }
}