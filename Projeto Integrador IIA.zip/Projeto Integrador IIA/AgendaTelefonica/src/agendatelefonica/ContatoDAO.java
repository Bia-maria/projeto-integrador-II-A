package agendatelefonica;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ContatoDAO {

    public void adicionarContato(Contato contato) {

        String sql = "INSERT INTO contato(nome, telefone, email) VALUES (?, ?, ?)";

        try {

            Connection con = Conexao.conectar();

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, contato.getNome());
            stmt.setString(2, contato.getTelefone());
            stmt.setString(3, contato.getEmail());

            stmt.executeUpdate();

            System.out.println("Contato cadastrado com sucesso!");

            stmt.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void listarContatos() {

        String sql = "SELECT * FROM contato";

        try {

            Connection con = Conexao.conectar();

            PreparedStatement stmt = con.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                System.out.println("--------------------");
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Nome: " + rs.getString("nome"));
                System.out.println("Telefone: " + rs.getString("telefone"));
                System.out.println("Email: " + rs.getString("email"));
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void buscarContato(String nome) {

        String sql = "SELECT * FROM contato WHERE nome = ?";

        try {

            Connection con = Conexao.conectar();

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, nome);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Nome: " + rs.getString("nome"));
                System.out.println("Telefone: " + rs.getString("telefone"));
                System.out.println("Email: " + rs.getString("email"));

            } else {

                System.out.println("Contato não encontrado.");

            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void removerContato(String nome) {

        String sql = "DELETE FROM contato WHERE nome = ?";

        try {

            Connection con = Conexao.conectar();

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, nome);

            int linhas = stmt.executeUpdate();

            if (linhas > 0) {

                System.out.println("Contato removido com sucesso!");

            } else {

                System.out.println("Contato não encontrado.");

            }

            stmt.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }
    }

    public void atualizarContato(String nome,
                                 String telefone,
                                 String email) {

        String sql =
                "UPDATE contato SET telefone = ?, email = ? WHERE nome = ?";

        try {

            Connection con = Conexao.conectar();

            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, telefone);
            stmt.setString(2, email);
            stmt.setString(3, nome);

            int linhas = stmt.executeUpdate();

            if (linhas > 0) {

                System.out.println("Contato atualizado com sucesso!");

            } else {

                System.out.println("Contato não encontrado.");

            }

            stmt.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
}