package agendatelefonica;

import java.sql.Connection;
import java.sql.DriverManager;

public class TesteConexao {

    public static void main(String[] args) {

        try {

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/agenda_telefonica",
                "root",
                "Agenda@2026!"
            );

            System.out.println("Conectado com sucesso!");

            con.close();

        } catch (Exception e) {

            System.out.println("Erro ao conectar:");
            e.printStackTrace();

        }
    }
}
