package agendatelefonica;

public class TesteBusca {

    public static void main(String[] args) {

        ContatoDAO dao = new ContatoDAO();

        dao.buscarContato("Maria");

    }
}