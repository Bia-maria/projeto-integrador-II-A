package agendatelefonica;

public class TesteListagem {

    public static void main(String[] args) {

        ContatoDAO dao = new ContatoDAO();

        dao.listarContatos();

    }
}