package agendatelefonica;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

    private static final String URL =
            "jdbc:mysql://localhost:3306/agenda_telefonica";

    private static final String USER = "root";

    private static final String PASSWORD = "Agenda@2026!";

    public static Connection conectar() throws Exception {

        return DriverManager.getConnection(
                URL,
                USER,
                PASSWORD
        );
    }
}