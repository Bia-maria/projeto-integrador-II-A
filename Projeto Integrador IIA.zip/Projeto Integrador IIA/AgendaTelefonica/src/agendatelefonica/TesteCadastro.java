package agendatelefonica;

public class TesteCadastro {

    public static void main(String[] args) {

        Contato contato = new Contato(
                "João Silva",
                "(62)98888-7777",
                "joao@email.com"
        );

        ContatoDAO dao = new ContatoDAO();

        dao.adicionarContato(contato);

    }
}