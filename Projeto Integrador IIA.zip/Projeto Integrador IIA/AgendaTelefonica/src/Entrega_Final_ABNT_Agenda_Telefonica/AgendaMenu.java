import java.sql.*;
import java.util.Scanner;

public class AgendaMenu {

    static String url = "jdbc:mysql://localhost:3306/agenda_telefonica";
    static String user = "root";
    static String password = "Agenda@2026!";

    public static void main(String[] args) {
        try {
            Connection con = DriverManager.getConnection(
                    url,
                    user,
                    password
            );

            System.out.println("Conectado ao MySQL com sucesso!");
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}