CREATE DATABASE agenda_telefonica;

USE agenda_telefonica;

CREATE TABLE contato (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(100)
);

SELECT * FROM contato;
INSERT INTO contato(nome, telefone, email)
VALUES ('Maria', '(62)99999-9999', 'maria@email.com');